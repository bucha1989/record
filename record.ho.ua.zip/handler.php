<?php

/**
 * @author Buchastiy Sergey
 * @copyright 2016
 */

echo 'hello';

?>